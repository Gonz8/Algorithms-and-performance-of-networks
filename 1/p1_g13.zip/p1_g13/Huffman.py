from classes_functions import is_number, HuffmanCode
import sys

f = open(str(sys.argv[1]),"r") #To run this script with 'test.txt' text file one should write 'python Huffman.py test.txt'
Symbols = []
Freqs = []
i = 0
for word in f.read().split():
	if (i % 2 == 0): #even index
		Symbols.append(word)
	else:
		assert(is_number(word)) # freq must be a number !
		Freqs.append(float(word))
	i += 1
f.closed

HuffmanCode(Symbols, Freqs)
